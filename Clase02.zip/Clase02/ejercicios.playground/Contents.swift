//: Playground - noun: a place where people can play

import UIKit
class myClass{
    var arreglo : [String] = ["uno","dos","tres","cuatro"]
    
    func buscar	(valor : String	)->String{
        var encontrado:String = ""
        for(ivalor,i) in arreglo{
            if(ivalor==valor){
                encontrado = ivalor
            }
            
        }
    }
}


//{}[String]
