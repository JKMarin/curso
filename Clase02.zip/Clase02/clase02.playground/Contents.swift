//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var var2 : String =  "Nueva Variable"

str = "nuevo nombre"

var edad : Int = 34

var masViejo = edad + 345

let constante : String = "Esto no se puede Cambiar"

var verdadero : Bool = false

let PI : Double = 3.1415

