//
//  ViewController.swift
//  clase02.dice
//
//  Created by Estudiantes on 7/4/18.
//  Copyright © 2018 Juan Carlos Marin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var prtDado1:Int = 0
    var prtDado2:Int = 0
    let arregloImagenes:[String] = ["dice1","dice2","dice3","dice4","dice5","dice6"]
    
    @IBOutlet weak var imgDice1: UIImageView!
    @IBOutlet weak var imgDice2: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func btnTirarDados(_ sender: UIButton) {
        prtDado1 = Int(arc4random_uniform(6))
        prtDado2 = Int(arc4random_uniform(6))
        
        imgDice1.image = UIImage(named:arregloImagenes[prtDado1])
        imgDice2.image = UIImage(named:arregloImagenes[prtDado2])
    }
    
}


