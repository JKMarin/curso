//
//  ViewController.swift
//  bolamagica
//
//  Created by Estudiantes on 14/4/18.
//  Copyright © 2018 Juan Carlos Marin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let arregloImagenes:[String] = ["ball1","ball2","ball3","ball4","ball5"]
    
    @IBOutlet weak var imgPreguntas: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func buscarPreguntaRandom(){
        var prtPregunta:Int = 0
        prtPregunta = Int(arc4random_uniform(5))
        for indice:Int in 1...5 {
            if indice == prtPregunta     {
                imgPreguntas.image = UIImage(named:arregloImagenes[indice])
            }
        }
        
    }

    @IBAction func clickPreguntar(_ sender: UIButton) {
        buscarPreguntaRandom()
    }
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
        buscarPreguntaRandom()
        
    }
}

